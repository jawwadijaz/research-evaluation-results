| Config | Utility (benign) | Utility (under attack) | ASR [95% CI] | Confirm./benign task | n benign / n attacked |
|---|---|---|---|---|---|
| C0 | 30.0% | 33.7% | 9.4% [6.8, 12.9] | 0.00 | 40 / 350 |
| C3-approve | 37.5% | 32.6% | 1.1% [0.4, 2.9] | 0.45 | 40 / 350 |
| C3-reject | 27.5% | 31.1% | 0.3% [0.1, 1.6] | 0.23 | 40 / 350 |

**Per-suite ASR**

| Config | banking | slack | travel | workspace |
|---|---|---|---|---|
| C0 | 11.1% | 38.0% | 5.7% | 0.0% |
| C3-approve | 0.0% | 4.0% | 2.9% | 0.0% |
| C3-reject | 0.0% | 0.0% | 1.4% | 0.0% |

**Paired comparisons of ASR (exact McNemar, same task pairs)**

- C0 vs C3-approve: n=350, only C0 attacked=31, only C3-approve attacked=2, p=1.31e-07
- C0 vs C3-reject: n=350, only C0 attacked=32, only C3-reject attacked=0, p=4.66e-10
- C3-approve vs C3-reject: n=350, only C3-approve attacked=3, only C3-reject attacked=0, p=0.25

**Blocked calls by reason**

- C3-approve: INV-3=30, allow-list=197
- C3-reject: INV-2=72, INV-3=31, allow-list=202
